<?php

use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', [\App\Http\Controllers\HomeController::class, 'index'])->name('home');

Route::get('track', [\App\Http\Controllers\TrackingController::class, 'index'])->name('track.index');
Route::post('track/follow', [\App\Http\Controllers\TrackingController::class, 'show'])->name('track.follow');

Route::get('ticket', [\App\Http\Controllers\TicketController::class, 'create'])->name('ticket.create');
Route::post('ticket/store', [\App\Http\Controllers\TicketController::class, 'store'])->name('ticket.store');

Route::get('settings', [\App\Http\Controllers\SettingsController::class, 'index'])->name('settings');
Route::post('settings', [\App\Http\Controllers\SettingsController::class, 'update'])->name('settings.update');

// Redirect GET requests for /track/follow
Route::get('track/follow', function () {
    return redirect()->to(route('track.index'));
});

// Clientele area
Route::prefix('client')->middleware('auth')->group(function () {
    Route::get('/', [App\Http\Controllers\Clientele\HomeController::class, 'index'])->name('clientele.index');

    Route::get('tickets', [\App\Http\Controllers\Clientele\TicketController::class, 'index'])->name('clientele.tickets.index');
    Route::get('tickets/{ticket}', [\App\Http\Controllers\Clientele\TicketController::class, 'show'])->name('clientele.tickets.show');

    Route::get('appointment-history/{id}', [\App\Http\Controllers\Clientele\HomeController::class, 'previousAppointments'])->name('clientele.appointments');
    Route::get('medication-history/{id}', [\App\Http\Controllers\Clientele\HomeController::class, 'medication'])->name('clientele.medication');
});

// Admin area
Route::prefix('admin')->middleware(['auth', 'admin'])->group(function () {
    Route::get('/', [\App\Http\Controllers\Admin\HomeController::class, 'index'])->name('admin.index');

    Route::get('appointment/create', [\App\Http\Controllers\AppointmentController::class, 'create'])->name('appointment.create');
    Route::post('appointment/store', [\App\Http\Controllers\AppointmentController::class, 'store'])->name('appointment.store');
    Route::get('appointment/show', [\App\Http\Controllers\AppointmentController::class, 'show'])->name('appointment.show');
    Route::get('appointment/edit/{appointment}', [\App\Http\Controllers\AppointmentController::class, 'edit'])->name('appointment.edit');
    Route::get('appointment/delete/{id}', [\App\Http\Controllers\AppointmentController::class, 'destroy'])->name('appointment.delete');
    Route::post('appointment/update/{id}', [\App\Http\Controllers\AppointmentController::class, 'update'])->name('appointment.update');

    Route::get('medicine/show', [App\Http\Controllers\MedicineController::class, 'show'])->name('medicine.show');
    Route::get('medicine/create', [App\Http\Controllers\MedicineController::class, 'create'])->name('medicine.create');
    Route::post('medicine/store', [App\Http\Controllers\MedicineController::class, 'store'])->name('medicine.store');
    Route::get('medicine/edit/{medicine}', [App\Http\Controllers\MedicineController::class, 'edit'])->name('medicine.edit');
    Route::get('medicine/delete/{id}', [App\Http\Controllers\MedicineController::class, 'destroy'])->name('medicine.delete');
    Route::post('medicine/update/{id}', [App\Http\Controllers\MedicineController::class, 'update'])->name('medicine.update');
});

// Tickets
Route::get('tickets', [\App\Http\Controllers\Admin\TicketController::class, 'index'])->name('admin.tickets.index');
Route::get('tickets/show/{ticket}', [\App\Http\Controllers\Admin\TicketController::class, 'show'])->name('admin.tickets.show');

// Authentication
Route::get('login', [App\Http\Controllers\Auth\LoginController::class, 'showLoginForm'])->name('login');
Route::post('login', [App\Http\Controllers\Auth\LoginController::class, 'login']);
Route::post('logout', [App\Http\Controllers\Auth\LoginController::class, 'logout'])->name('logout');

Route::get('register', [App\Http\Controllers\Auth\RegisterController::class, 'showRegistrationForm'])->name('register');
Route::post('register', [App\Http\Controllers\Auth\RegisterController::class, 'register']);

Route::get('password/reset', [App\Http\Controllers\Auth\ForgotPasswordController::class, 'showLinkRequestForm'])->name('password.request');
Route::post('password/email', [App\Http\Controllers\Auth\ForgotPasswordController::class, 'sendResetLinkEmail'])->name('password.email');
Route::get('password/reset/{token}', [App\Http\Controllers\Auth\ResetPasswordController::class, 'showResetForm'])->name('password.reset');
Route::post('password/reset', [App\Http\Controllers\Auth\ResetPasswordController::class, 'reset'])->name('password.update');

Route::get('password/confirm', [App\Http\Controllers\Auth\ConfirmPasswordController::class, 'showConfirmForm'])->name('password.confirm');
Route::post('password/confirm', [App\Http\Controllers\Auth\ConfirmPasswordController::class, 'confirm']);

Route::get('email/verify', [App\Http\Controllers\Auth\VerificationController::class, 'show'])->name('verification.notice');
Route::get('email/verify/{id}/{hash}', [App\Http\Controllers\Auth\VerificationController::class, 'verify'])->name('verification.verify');
Route::post('email/resend', [App\Http\Controllers\Auth\VerificationController::class, 'resend'])->name('verification.resend');
