<?php

namespace Tests\Unit;

use App\Models\User;
use Illuminate\Support\Str;
use Tests\TestCase;

class UserTest extends TestCase
{
    protected $response;
    /**
     * A basic unit test example.
     *
     * @return void
     */
    public function testStore()
    {
        $user = User::factory()->create();

        $this->response = $this->actingAs($user)
                         ->get('/');

        $this->assertEquals(302, $this->response->status());
    }
}
