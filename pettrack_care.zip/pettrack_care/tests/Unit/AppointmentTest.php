<?php

namespace Tests\Unit;

use App\Models\Appointment;
use App\models\User;
use App\models\Patient;
use Tests\TestCase;

class AppointmentTest extends TestCase
{
    /**
     * A basic unit test example.
     *
     * @return void
     */
    public function testUpdate()
    {
        $appointments = Appointment::get();

        $userData = [
            "expected_statuses" => 7,
            "appointment_at" => "2021-03-12 14:16:51"
        ];

        $this->json('POST', 'appointment/update/' . $appointments[0]->id , $userData, ['Accept' => 'application/json'])
            ->assertStatus(302);
    }
}
