<?php

return [
    'defaults' => [
        'notifications_updates' => 'off',
        'notifications_marketing' => 'off',
    ]
];
