@extends('layouts.app')
@section('content')
@if ($errors->any())
        <div class="alert alert-danger" role="alert">
            <strong>Er zijn één of meer fouten opgetreden:</strong><br/>
            @foreach ($errors->all() as $error)
                &bull; {{$error}}<br/>
            @endforeach
        </div>
@endif

<form action ="{{ route('appointment.store') }}" method="POST">
        @csrf
        <div class="form-group mt-3">
            <label for="name">Patient</label>

            <select name="patient_id" class="form-select mt-1">
                <option disabled selected>Selecteer een patient..</option>
                @foreach ($patients as $patient)
                    <option value="{{ $patient->id }}">{{ sprintf('%s - %s van %s (%s)', $patient->name, $patient->breed, $patient->owner->name, $patient->owner->email) }}</option>
                @endforeach
            </select>
        </div>

        <div class="form-group mt-3">
            <label for="name">Eigenaar/eigenaresse</label>

            <select name="owner_id" class="form-select mt-1">
                <option disabled selected>Selecteer een gebruiker..</option>
                @foreach ($users as $user)
                    <option value="{{ $user->id }}">{{ sprintf('%s (%s)', $user->name, $user->email) }}</option>
                @endforeach
            </select>
        </div>

        <div class="form-group mt-3">
            <label for="status">Verwacht aantal fases</label>

            <input type="number"
                   min="0"
                   max="20"
                   value="3"
                   class="form-control mt-1"
                   id="expected_statuses"
                   placeholder="Verwachtte status"
                   name="expected_statuses">
        </div>

        <div class="form-group mt-3">
            <label for="time">Tijd van de afspraak</label>

            <input type="text"
                   class="form-control mt-1"
                   id="appointment_at"
                   placeholder="Tijd van de afspraak"
                   name="appointment_at">
        </div>
        <button type="submit" class="btn btn-primary mt-3">Verzenden</button>
    </form>
@endsection
