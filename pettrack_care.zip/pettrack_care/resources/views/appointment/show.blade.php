@extends('layouts.app')
@section('content')
    @if(\Session::has('message'))
        <p class="alert alert-success">{{ \Session::get('message') }}</p>
    @endif

    <div class="mt-5">
        <a href="{{ route('appointment.create') }}" class="btn btn-primary">Maak nieuwe afspraak</a>
    </div>
    <br>

    <table class="table">
        <thead>
            <tr>
                <th scope="col">Patient</th>
                <th scope="col">Eigenaar/eigenaresse</th>
                <th scope="col">Verwachtte fases</th>
                <th scope="col">Ingepland op</th>
                <th scope="col">Acties</th>
            </tr>
        </thead>
        <tbody>
            @foreach( $appointments as $appointment )
            <tr>
                <th scope="row">{{ $appointment->patient->name }}</th>
                <td>{{ $appointment->owner->name }}</td>
                <td>{{ $appointment->expected_statuses }}</td>
                <td>{{ $appointment->appointment_at }} ({{ \Carbon\Carbon::parse($appointment->appointment_at)->diffForHumans() }})</td>
                <td>
                    <a href="{{ route('appointment.edit', ['appointment' => $appointment->id]) }}" class="btn btn-primary btn-sm">
                        Aanpassen
                    </a>
                    <a href="{{ route('appointment.delete', ['id' => $appointment->id]) }}" class="btn btn-danger btn-sm">
                        Verwijderen
                    </a>
                </td>
            </tr>
            @endforeach
        </tbody>
    </table>
@endsection
