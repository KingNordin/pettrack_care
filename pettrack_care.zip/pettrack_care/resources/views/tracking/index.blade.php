@extends('layouts.app')

@section('content')
    <h1>Behandeling volgen</h1>

    @if ($errors->any())
        <div class="alert alert-danger" role="alert">
            <b>Er zijn één of meer fouten opgetreden:</b><br/>
            @foreach ($errors->all() as $error)
                &bull; {{$error}}<br/>
            @endforeach
        </div>
    @endif

    <form class="mt-3" action="{{ route('track.follow') }}" method="POST">
        @csrf
        <div class="mb-3">
            <label for="code" class="form-label">Code van de afspraak</label>
            <input type="text"
                   class="form-control"
                   id="code"
                   name="code"
                   maxlength="19"
                   value="{{ old('code') }}"
                   placeholder="Bijv. 6573-2345-5643-2684">

            <div class="form-text">Deze code ontvangt u maximaal 24 uur vóór de behandeling van uw huisdier.</div>
        </div>

        <div class="mb-3">
            <label for="zipcode" class="form-label">Postcode eigenaar/eigenaresse</label>
            <input type="text"
                   class="form-control"
                   id="zipcode"
                   name="zipcode"
                   maxlength="7"
                   value="{{ old('zipcode') }}"
                   placeholder="Bijv. 1059 EP">
        </div>

        <button type="submit" class="btn btn-primary">Volgen</button>
    </form>

@endsection
