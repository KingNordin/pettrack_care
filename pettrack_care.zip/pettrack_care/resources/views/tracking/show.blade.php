@extends('layouts.app')

@section('content')
    <div class="container">
        <div class="row">
            <div class="col-xl-1 col-lg-4 col-sm-12">
                <img src="https://thiscatdoesnotexist.com/"
                     class="rounded"
                     width="80"
                     height="80"
                     alt="Picture of a pet">
            </div>
            <div class="col-xl-9 col-lg-4 col-sm-12 mt-3 mt-lg-0">
                <h5>{{ $appointment->patient->name }}</h5>
                <div>{{ $appointment->patient->breed }}</div>
                <div>
                    {{ \Carbon\Carbon::parse($appointment->patient->date_of_birth)->diffInYears() }} jaar
                    ({{ \Carbon\Carbon::parse($appointment->patient->date_of_birth)->format("d M. 'y") }})
                </div>
            </div>
            <div class="col-xl-2 col-lg-4 col-sm-12 text-lg-end text-start mt-3 mt-lg-0">
                <h5>
                    {{ $appointment->owner->name }}
                </h5>

                <div>
                    {{ sprintf('%s %d%s', $appointment->owner->street, $appointment->owner->house_number, $appointment->owner->addition) }}
                </div>
                <div>
                    {{ sprintf('%s %s', $appointment->owner->zipcode, $appointment->owner->city) }}
                </div>
            </div>
        </div>
    </div>

    <div class="card mt-5">
        <div class="form p-4">
            <label for="customRange1" class="form-label">
                <h5>{{ sprintf('Fase %d van %d', count($appointment->statuses), $appointment->expected_statuses) }}</h5>
                {{ $appointment->statuses->last()->description ?? '' }}
            </label>

            <div class="progress">
                <div class="progress-bar {{ count($appointment->statuses) < $appointment->expected_statuses ? 'progress-bar-striped progress-bar-animated' : '' }}"
                     role="progressbar"
                     style="width: {{ count($appointment->statuses) / $appointment->expected_statuses * 100 }}%"></div>
            </div>

            <div class="text-muted small mt-2">
                @foreach($appointment->statuses->reverse() as $index => $status)
                    &bull; {{ \Carbon\Carbon::parse($status->updated_at)->format("d M H:i") }} &mdash; {{ $status->description }}
                    {{ sprintf('(%d/%d)', ($index + 1), $appointment->expected_statuses) }}
                    <br/>
                @endforeach
            </div>

            <hr>

            <div class="pt-3 pb-3">
                <h3>(Medisch) Advies voor ná de behandeling</h3>
                <div class="mt-3">
                    @foreach ($appointment->aftercare as $item)
                        <div>
                            <p>&bull; {{ $item->content }}</p>
                        </div>
                    @endforeach
                </div>
            </div>

            <hr>

            <div>
                <p>
                    Heeft u nog vragen over de behandeling? Dan kunt u altijd contact met ons opnemen. Kies één van de
                    contactmogelijkheden hieronder.
                </p>

                <a href="{{ route("ticket.create", ["code" => $appointment->code->code, "zipcode" => $appointment->owner->zipcode]) }}" class="btn btn-primary">Vraag stellen</a>
                <a class="btn btn-outline-primary" data-bs-toggle="modal" data-bs-target="#callModal">
                    Telefonisch contact opnemen
                </a>

                @include('components/call-modal', ['minimal' => false])
            </div>
        </div>
    </div>
@endsection
