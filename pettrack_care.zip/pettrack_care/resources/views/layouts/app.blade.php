<!doctype html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport"
              content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
        <meta http-equiv="X-UA-Compatible" content="ie=edge">

        <title>{{ config('app.name') }}</title>

        <link rel="icon" href="{{ asset('favicon.ico', config('app.env') === 'production') }}">

        <!-- Bootstrap 5.0.0-beta1 -->
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/css/bootstrap.min.css"
              rel="stylesheet"
              integrity="sha384-giJF6kkoqNQ00vy+HMDP7azOuL0xtbfIcaT9wjKHr8RbDVddVHyTfAAsrekwKmP1"
              crossorigin="anonymous">

        <!-- FontAwesome 5.15.2 -->
        <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.2/css/all.min.css"
              rel="stylesheet">

        <!-- Own styling -->
        <link rel="stylesheet" href="{{ asset('css/app.css', config('app.env') === 'production') }}">

        <script src="{{ asset('js/app.js', config('app.env') === 'production') }}"></script>

        <!--DateTime picker -->
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/flatpickr/dist/flatpickr.min.css">
        <script src="https://cdn.jsdelivr.net/npm/flatpickr"></script>
        <script>
            $(function () {
                $('#appointment_at').flatpickr({
                    time_24hr: true,
                    enableTime: true,
                    dateFormat: "Y-m-d H:i:ss",
                });
            });

            $(document).ready(function(){
                $('.alert-success').fadeIn().delay(10000).fadeOut();
            });
        </script>
    </head>
    <body>
        <nav class="navbar navbar-dark bg-primary">
            <div class="container">
                <a class="navbar-brand" href="{{ route('home') }}">
                    <em class="fas fa-paw paw-icon"></em>
                    PetTrack&Care
                </a>
                <div class="d-flex">
                    <div class="button-group">
                        <a href="{{ route('track.index') }}" class="btn btn-light">Behandeling volgen</a>
                        <a href="{{ route('ticket.create') }}" class="btn btn-light">Contact</a>
                    </div>

                    <div class="nav-item dropdown">
                        @auth
                            <div class="btn text-white" id="navbarDropdownMenuLink" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                            <i class="fas fa-bars"></i>
                        </div>
                            <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="navbarDropdownMenuLink">
                                @if(auth()->user()->is_admin)
                                    <li>
                                        <a class="dropdown-item" href="{{ route('admin.index') }}">
                                            Administratie
                                        </a>
                                    </li>

                                    <li>
                                        <a class="dropdown-item" href="{{ route('admin.tickets.index') }}">
                                            Tickets
                                        </a>
                                    </li>
                                @else
                                    <li>
                                        <a class="dropdown-item" href="{{ route('clientele.index') }}">
                                            Mijn huisdieren
                                        </a>
                                    </li>

                                    <li>
                                        <a class="dropdown-item" href="{{ route('clientele.tickets.index') }}">
                                            Tickets
                                        </a>
                                    </li>
                                @endif

                                <li>
                                    <a class="dropdown-item" href="{{ route('settings') }}">
                                        Instellingen
                                    </a>
                                </li>

                                <li><hr class="dropdown-divider"></li>

                                <li>
                                    <a class="dropdown-item" href="#" onclick="event.preventDefault(); document.getElementById('logout-form').submit();">
                                        <i class="fas fa-sign-out-alt"></i>
                                        Uitloggen
                                    </a>
                                </li>

                                <form id="logout-form" action="{{ route('logout') }}" method="POST" style="display: none;">
                                    {{ csrf_field() }}
                                </form>
                            </ul>
                        @endauth
                    </div>
                </div>
            </div>
        </nav>

        <main class="container mt-5">
            @yield('content')
        </main>

        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta2/dist/js/bootstrap.bundle.min.js"
                integrity="sha384-b5kHyXgcpbZJO/tY9Ul7kGkf1S0CWuKcCD38l8YkeH8z8QjE0GmW1gYU5S9FOnJ0"
                crossorigin="anonymous"></script>
    </body>
</html>
