@extends('layouts.app')
@section('content')
<h1>Aftercare</h1>
<div class="mt-5">
    <a href="{{ route('aftercare.create') }}" class="btn btn-primary">Aftercare aanmaken</a>
</div>
<div class="mt-5">
    <a href="{{ route('aftercare.show') }}" class="btn btn-primary">Aftercare inzien</a>
</div>
@endsection
