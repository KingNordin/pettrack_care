@extends('layouts.app')
@section('content')
    @if ($errors->any())
        <div class="alert alert-danger" role="alert">
            <strong>Er zijn één of meer fouten opgetreden:</strong><br/>
            @foreach ($errors->all() as $error)
            &bull; {{$error}}<br/>
            @endforeach
        </div>
    @endif
    <form action ="{{ route('aftercare.store') }}" method="POST">
        <div class="form-group mt-3">
            <label for="name">Huisdier</label>
            <select name='huisdier' id="huisdier">
                @foreach($patientId as $patientnum)
                    <option value="{{$patientnum->name}}">{{$patientnum->name}} </option>
                @endforeach
            </select>
        </div>
        <button type="submit" class="btn btn-primary mt-3">Verzenden</button>

    </form>

@endsection
