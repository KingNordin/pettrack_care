@extends('layouts.app')
@section('content')
    @if ($errors->any())
        <div class="alert alert-danger" role="alert">
            <strong>Er zijn één of meer fouten opgetreden:</strong><br/>
            @foreach ($errors->all() as $error)
            &bull; {{$error}}<br/>
            @endforeach
        </div>
    @endif

    <form action ="{{ route('aftercare.store') }}" method="POST">
        @csrf
        <div class="form-group mt-3">
            <label for="name">Medicijn</label>
         <select name='medicijn' id="medicijn">
             @foreach($medicine as $medicines)
             <option value="{{$medicines->name}}">{{$medicines->name}} </option>
             @endforeach
         </select>
        </div>
        <div class="form-group mt-3">
            <label for="name">Eigenaar</label>
            <select name='eigenaar' id="eigenaar">
                @foreach($ownerId as $ownernum)
                    <option value="{{$ownernum->name}}">{{$ownernum->name}} </option>
                @endforeach
            </select>
        </div>
        <div class="form-group mt-3">
            <label for="name">Huisdier</label>
            <select name='huisdier' id="huisdier">
                @foreach($patientId as $patientnum)
                    <option value="{{$patientnum->id}}">{{$patientnum->id}} </option>
                @endforeach
            </select>
        </div>
        <div class="form-group mt-3">
            <label for="name">afspraak</label>
            <select name='afspraak' id="afspraak">
                @foreach($appointment as $appointments)
                    <option value="{{$appointments->id}}">{{$appointments->id}} </option>
                @endforeach
            </select>
        </div>


        <button type="submit" class="btn btn-primary mt-3">Verzenden</button>
    </form>
@endsection
