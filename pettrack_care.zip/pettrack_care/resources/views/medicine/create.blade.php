@extends('layouts.app')
@section('content')
    @if ($errors->any())
        <div class="alert alert-danger" role="alert">
            <strong>Er zijn één of meer fouten opgetreden:</strong><br/>
            @foreach ($errors->all() as $error)
            &bull; {{$error}}<br/>
            @endforeach
        </div>
    @endif

    <form action ="{{ route('medicine.store') }}" method="POST">
        @csrf
        <div class="form-group mt-3">
            <label for="name">Naam van het medicijn</label>
            <input type="text"
                   class="form-control"
                   id="patient_medicine"
                   placeholder="Naam van het medicijn"
                   name="patient_medicine">
        </div>
        <div class="form-group mt-3">
            <label for="name">Beschrijving van het medicijn</label>
            <input type="text"
                   class="form-control"
                   id="patient_medicine_desc"
                   placeholder="Vul hier de beschrijving in"
                   name="patient_medicine_desc">
        </div>
        <div class="form-group mt-3">
            <label for="name">Gebruik van het medicijn</label>
            <input type="text"
                   class="form-control"
                   id="patient_medicine_use"
                   placeholder="Vul hier het gebruik in"
                   name="patient_medicine_use">
        </div>
        <button type="submit" class="btn btn-primary mt-3">verzenden</button>
    </form>
@endsection
