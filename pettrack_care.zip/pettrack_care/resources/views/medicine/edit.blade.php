@extends('layouts.app')

@section('content')

    @if ($errors->any())
        <div class="alert alert-danger" role="alert">
            <b>Er zijn één of meer fouten opgetreden:</b><br/>
            @foreach ($errors->all() as $error)
            &bull; {{$error}}<br/>
            @endforeach
        </div>
    @endif

    <form action ="{{ route('medicine.update', ['id' => $medicine->id]) }}" method="POST">
        @csrf
        <div class="form-group mt-3">
            <label for="name">Naam van het medicijn</label>
            <input type="text"
                   class="form-control"
                   id="patient_medicine"
                   placeholder="Nieuwe naam van het medicijn"
                   name="patient_medicine"
                   value="{{ $medicine->name }}">
        </div>

        <div class="form-group mt-3">
            <label for="description">Beschrijving van het medicijn</label>
            <input type="text"
                   class="form-control"
                   id="patient_medicine_desc"
                   placeholder="Nieuwe beschrijving van het medicijn"
                   name="patient_medicine_desc"
                   value="{{ $medicine->description }}" >
        </div>
        <div class="form-group mt-3">
            <label for="usage">Gebruik van het medicijn</label>
            <input type="text"
                   class="form-control"
                   id="patient_medicine_use"
                   placeholder="Nieuw gebruik van het medicij"
                   name="patient_medicine_use"
                   value="{{ $medicine->usage }}">
        </div>
        <button type="submit" class="btn btn-primary mt-3">Verzenden</button>
    </form>
@endsection
