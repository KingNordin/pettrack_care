@extends('layouts.app')
@section('content')
    @if(\Session::has('message'))
        <p class="alert alert-success">{{ \Session::get('message') }}</p>
    @endif

    <div class="mt-5">
        <a href="{{ route('medicine.create') }}" class="btn btn-primary">Medicijnen aanmaken</a>
    </div>
    <br>
<table class="table">
        <thead>
            <tr>
                <th scope="col">Medicijn</th>
                <th scope="col">Beschrijving</th>
                <th scope="col">Dosering</th>
                <th scope="col">Acties</th>
            </tr>
        </thead>
        <tbody>
            @foreach( $medicines as $medicine )
            <tr>
                <th scope="row">{{ $medicine->name }}</th>
                <td>{{ $medicine->description }}</td>
                <td>{{ $medicine->usage }}</td>
                <td>
                    <a href="{{ route('medicine.edit', ['medicine' => $medicine->id]) }}" class="btn btn-primary btn-sm">
                        Aanpassen
                    </a>
                    <a href="{{ route('medicine.delete', ['id' => $medicine->id]) }}" class="btn btn-danger btn-sm">
                        Verwijderen
                    </a>
                </td>
            </tr>
            @endforeach
        </tbody>
    </table>
@endsection
