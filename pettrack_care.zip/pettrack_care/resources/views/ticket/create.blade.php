@extends('layouts.app')

@section('content')

    <h1>Vraag stellen aan de praktijk</h1>
    <div class="alert alert-warning" role="alert">
        <i class="fas fa-exclamation-triangle"></i>&nbsp;
        Betreft uw vraag een noodsituatie?
        <a href="#" class="text-dark" data-bs-toggle="modal" data-bs-target="#callModal">Klik dan hier</a> om de praktijk te bellen.
    </div>

    @include('components/call-modal', ['minimal' => true])

    @if ($errors->any())
        <div class="alert alert-danger">
            <ul>
                @foreach ($errors->all() as $error)
                    <li>{{ $error }}</li>
                @endforeach
            </ul>
        </div>
    @endif

    <form action ="{{ route('ticket.store') }}" method="POST">
        @csrf
        <div class="form-group">
            <label for="name">Naam</label>
            <input type="text"
                   class="form-control"
                   id="name"
                   {{ auth()->check() ? 'readonly' : '' }}
                   placeholder="Uw naam"
                   name="name"
                   value="{{ auth()->check() ? auth()->user()->name : old('name', $appointment !== null ? $appointment->owner->name : null) }}">
            @auth
                <small class="text-muted">Automatisch ingevuld omdat je bent ingelogd.</small>
            @endauth
        </div>

        <div class="form-group mt-3">
            <label for="email">E-mailadres</label>
            <input type="email"
                   class="form-control"
                   id="email"
                   {{ auth()->check() ? 'readonly' : '' }}
                   aria-describedby="emailHelp"
                   placeholder="Uw e-mailadres"
                   name="email"
                   value="{{ auth()->check() ? auth()->user()->email : old('email', $appointment !== null ? $appointment->owner->email : null) }}">
            @auth
                <small class="text-muted">Automatisch ingevuld omdat je bent ingelogd.</small>
            @endauth
        </div>

        <div class="form-group mt-3">
            <label for="animal">Dier in kwestie (indien toepasselijk aan uw vraag)</label>
            <input type="text"
                   class="form-control"
                   id="animal"
                   placeholder="De naam van uw huisdier"
                   name="pet_name"
                   value="{{ old('pet_name', $appointment !== null ? $appointment->patient->name : null) }}">
        </div>

        <div class="form-group mt-3">
            <label for="category">Categorie</label>
            <div class="input-group mb-3">
                <select class="form-select"
                        id="category"
                        name="category_id">
                    <option selected disabled>Selecteer categorie..</option>
                    @foreach($categories as $category)
                        @if (old('category_id') == $category->id)
                            <option value="{{ $category->id }}" selected>{{ $category->name }}</option>
                        @else
                            <option value="{{ $category->id }}">{{ $category->name }}</option>
                        @endif
                    @endforeach
                </select>
            </div>
        </div>

        <div class="form-group mt-3">
            <label for="subject">Onderwerp</label>
            <input type="text"
                   class="form-control"
                   id="subject"
                   placeholder="Het onderwerp van uw vraag"
                   name="subject"
                   value="{{ old('subject') }}">
        </div>

        <div class="form-group mt-3">
            <label for="content">Omschrijving van uw vraag</label>
            <textarea class="form-control"
                      id="content"
                      rows="3"
                      name="content">{{ old('content') }}</textarea>
        </div>

        <button type="submit" class="btn btn-primary mt-3">Verzenden</button>
    </form>
@endsection
