@extends('layouts.app')

@section('content')
    <h1>Bedankt voor het versturen van uw vraag!</h1>
    <p>
        Wij streven ernaar om alle vragen binnen 48 uur te beantwoorden via e-mail, tenzij anders aangegeven.
    </p>

    <div class="mt-4">
        <a href="{{ route('home') }}" class="btn btn-primary">Ga terug</a>
    </div>
@endsection
