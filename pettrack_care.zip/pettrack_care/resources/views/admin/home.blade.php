@extends('layouts.app')

@section('content')
    <h1>Administratie</h1>
    <p>
        Binnen het administratie-portaal kun je makkelijk afspraken inplannen, tickets inzien (en beantwoorden), je
        instellingen aanpassen en het medicatieregister inzien/bijwerken.
    </p>

    <div class="card-group row mt-5">
        <div class="col">
            <div class="card">
                <div class="card-img-top card-pattern pattern-one"></div>
                <div class="card-body">
                    <h5 class="card-title">Afspraak inplannen</h5>
                    <p class="card-text">Gemakkelijk een nieuwe afspraak inplannen met behulp van het klantbestand.</p>
                    <a href="{{ route('appointment.show') }}" class="btn btn-primary">Ga naar 'Afspraken'</a>
                </div>
            </div>
        </div>

        <div class="col">
            <div class="card">
                <div class="card-img-top card-pattern pattern-two"></div>
                <div class="card-body">
                    <h5 class="card-title">Klantenservice</h5>
                    <p class="card-text">Krijg inzicht in de vragen die klanten gesteld hebben met de mogelijkheid om te antwoorden.</p>
                    <a href="{{ route('admin.tickets.index') }}" class="btn btn-primary">Ga naar 'Tickets'</a>
                </div>
            </div>
        </div>

        <div class="col">
            <div class="card">
                <div class="card-img-top card-pattern pattern-three"></div>
                <div class="card-body">
                    <h5 class="card-title">Instellingen</h5>
                    <p class="card-text">
                        Hier kun je gemakkelijk je persoonlijke instellingen wijzigen. Denk aan notificaties, etc.
                    </p>
                    <a href="{{ route('settings') }}" class="btn btn-primary">Ga naar 'Instellingen'</a>
                </div>
            </div>
        </div>

        <div class="col">
            <div class="card">
                <div class="card-img-top card-pattern pattern-four"></div>
                <div class="card-body">
                    <h5 class="card-title">Medicijnen</h5>
                    <p class="card-text">
                        Hier kunnen de medewerkers het medicatieregister (beschikbaar voor afspraken) bijhouden.
                    </p>
                    <a href="{{ route('medicine.show') }}" class="btn btn-primary">Ga naar 'Medicijnen'</a>
                </div>
            </div>
        </div>
    </div>
@endsection
