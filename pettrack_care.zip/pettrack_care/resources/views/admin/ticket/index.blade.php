@extends('layouts.app')

@section('content')
    <h1>Tickets</h1>

    @if (count($tickets) >= 1)
    <table class="table">
        <thead>
            <tr>
                <th>&nbsp;</th>
                <th>Onderwerp</th>
                <th>Naam</th>
                <th>Categorie</th>
                <th>Acties</th>
            </tr>
        </thead>
        <tbody>
            @foreach ($tickets as $ticket)
                <tr class="{{ $ticket->is_read ? '' : ' ' }}">
                    <td>
                        @if((bool) $ticket->is_read === false)
                            <span class="pulse"></span>
                        @endif
                    </td>
                    @if((bool) $ticket->is_read === false)
                        <th>{{ $ticket->subject }}</th>
                    @else
                        <td>{{ $ticket->subject }}</td>
                    @endif
                    <td>{{ $ticket->name }}</td>
                    <td>{{ $ticket->category->name }}</td>
                    <td>
                        <a href="{{ route('admin.tickets.show', ['ticket' => $ticket->id]) }}"
                           class="btn btn-primary btn-sm">
                            Openen
                        </a>
                    </td>
                </tr>
            @endforeach
        </tbody>
    </table>
    @else
    <p>
        Er zijn nog geen vragen/opmerkingen opgestuurd door cliënten, echter zullen ze hier verschijnen zodra dat wel zo is.
    </p>
    @endif
@endsection
