<div class="form-group">

    <div class="row">
        <div class="col-12 col-md-4">

            <div class="mb-3">
                <label for="nameField" class="form-label">Naam</label>
                <input type="email" class="form-control" id="nameField" disabled name="name" value="{{ auth()->user()->name }}">
            </div>

            <div class="mb-3">
                <label for="emailField" class="form-label">Email address</label>
                <input type="email" class="form-control" id="emailField" disabled value="{{ auth()->user()->email }}">
            </div>

        </div>
    </div>

</div>
