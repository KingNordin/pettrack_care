<div class="form-check mb-3">
    @if($settings->get('notifications_marketing') === 'on')
        <input class="form-check-input" type="checkbox" name="notifications_marketing" id="notifications_marketing" checked>
    @else
        <input class="form-check-input" type="checkbox" name="notifications_marketing" id="notifications_marketing">
    @endif
    <label class="form-check-label" for="notifications_marketing">
        Ik wil marketing e-mails ontvangen
    </label>
</div>

<div class="form-check">
    @if($settings->get('notifications_updates') === 'on')
        <input class="form-check-input" type="checkbox" name="notifications_updates" id="notifications_updates" checked>
    @else
        <input class="form-check-input" type="checkbox" name="notifications_updates" id="notifications_updates">
    @endif
    <label class="form-check-label" for="notifications_updates">
        Ik wil updates ontvangen over behandelingen van mijn huisdier(en)
    </label>
</div>
