@extends('layouts.app')

@section('content')
    <h1>Instellingen</h1>

    <div class="mt-3">

        <div class="row">
            <div class="col-12 col-md-9">
                <ul class="nav nav-pills mb-3" id="pills-tab" role="tablist">
                    <li class="nav-item" role="presentation">
                        <button class="nav-link btn active"
                                id="pills-profile-tab"
                                data-bs-toggle="pill"
                                data-bs-target="#pills-profile"
                                type="button"
                                role="tab"
                                aria-controls="pills-profile"
                                aria-selected="true">Profielgegevens</button>
                    </li>

                    <li class="nav-item" role="presentation">
                        <button class="nav-link btn"
                                id="pills-notifications-tab"
                                data-bs-toggle="pill"
                                data-bs-target="#pills-notifications"
                                type="button"
                                role="tab"
                                aria-controls="pills-notifications"
                                aria-selected="false">Notificaties</button>
                    </li>
                </ul>
            </div>

            <div class="col-12 col-md-3">
                <li class="nav-item btn btn-success" onclick="event.preventDefault(); document.getElementById('settings-form').submit();">
                    Instellingen opslaan
                </li>
            </div>
        </div>

        <form action="{{ route('settings.update') }}" method="POST" id="settings-form">
            @csrf

            <div class="tab-content mt-3" id="pills-tabContent">
                <div class="tab-pane show active" id="pills-profile" role="tabpanel" aria-labelledby="pills-profile-tab">
                    @include('settings.components.profile_settings')
                </div>

                <div class="tab-pane" id="pills-notifications" role="tabpanel" aria-labelledby="pills-notifications-tab">
                    @include('settings.components.notifications')
                </div>
            </div>
        </form>

    </div>
@endsection
