<form class="form-group mt-3" method="POST" action="{{ route('login') }}">
    @csrf

    <div class="mb-3 col-12 col-md-12">
        <input type="email"
               name="email"
               value="{{ old('email') }}"
               class="form-control form-control-lg @error('email')is-invalid @enderror"
               placeholder="E-mailadres">

        @error('email')
        <span class="invalid-feedback" role="alert">
            <strong>{{ $message }}</strong>
        </span>
        @enderror
    </div>

    <div class="mb-3 col-12 col-md-12">
        <input type="password"
               class="form-control form-control-lg @error('password')is-invalid @enderror"
               name="password"
               placeholder="Wachtwoord">

        @error('password')
        <span class="invalid-feedback" role="alert">
            <strong>{{ $message }}</strong>
        </span>
        @enderror
    </div>

    <button type="submit" class="mb-2 col-12 col-md-12 btn btn-primary btn-lg">
        Aanmelden
    </button>

    <div class="col-12 col-md-12 text-center">
        <a href="{{ route('password.request') }}" class="text-decoration-none">Wachtwoord vergeten?</a>
    </div>

    <hr class="col-12 col-md-12">

    <div class="col-12 col-md-12 text-center">
        <a href="{{ route('register') }}" type="submit" class="mb-3 btn btn-success btn-lg">
            Nieuw account maken
        </a>
    </div>
</form>
