<form class="form-group mt-3" method="POST" action="{{ route('register') }}">
    @csrf

    <div class="mb-3 col-12 col-md-12">
        <input type="name"
               name="name"
               value="{{ old('name') }}"
               class="form-control form-control-lg @error('name')is-invalid @enderror"
               placeholder="Naam">

        @error('name')
        <span class="invalid-feedback" role="alert">
            <strong>{{ $message }}</strong>
        </span>
        @enderror
    </div>

    <div class="mb-3 col-12 col-md-12">
        <input type="email"
               name="email"
               value="{{ old('email') }}"
               class="form-control form-control-lg @error('email')is-invalid @enderror"
               placeholder="E-mailadres">

        @error('email')
        <span class="invalid-feedback" role="alert">
            <strong>{{ $message }}</strong>
        </span>
        @enderror
    </div>

    <div class="mb-3 col-12 col-md-12">
        <input type="password"
               class="form-control form-control-lg @error('password')is-invalid @enderror"
               name="password"
               placeholder="Wachtwoord">

        @error('password')
        <span class="invalid-feedback" role="alert">
            <strong>{{ $message }}</strong>
        </span>
        @enderror
    </div>

    <div class="row">
        <div class="col-md-6">
            <input id="street"
                   type="text"
                   class="form-control @error('street')is-invalid @enderror"
                   name="street"
                   value="{{ old('street') }}"
                   placeholder="Straat">

            @error('street')
            <span class="invalid-feedback" role="alert">
                <strong>{{ $message }}</strong>
            </span>
            @enderror
        </div>

        <div class="col-md-3">
            <input id="house_number"
                   type="text"
                   class="form-control @error('house_number')is-invalid @enderror"
                   name="house_number"
                   value="{{ old('house_number') }}"
                   placeholder="Huisnr.">
        </div>

        <div class="col-md-3">
            <input id="addition"
                   type="text"
                   class="form-control @error('addition')is-invalid @enderror"
                   placeholder="Toev."
                   name="addition"
                   value="{{ old('addition') }}">

            @error('addition')
            <span class="invalid-feedback" role="alert">
                <strong>{{ $message }}</strong>
            </span>
            @enderror
        </div>
    </div>

    <div class="row mt-3">
        <div class="col-md-7">
            <input id="city"
                   type="text"
                   class="form-control @error('city')is-invalid @enderror"
                   name="city"
                   value="{{ old('city') }}"
                   placeholder="Stad">

            @error('city')
            <span class="invalid-feedback" role="alert">
                <strong>{{ $message }}</strong>
            </span>
            @enderror
        </div>

        <div class="col-md-5">
            <input id="zipcode"
                   type="text"
                   class="form-control @error('zipcode')is-invalid @enderror"
                   name="zipcode"
                   value="{{ old('zipcode') }}"
                   placeholder="Postcode">

            @error('zipcode')
            <span class="invalid-feedback" role="alert">
                <strong>{{ $message }}</strong>
            </span>
            @enderror
        </div>
    </div>


    <button type="submit" class="mt-3 col-12 col-md-12 btn btn-success btn-lg">
        Registreren
    </button>
</form>
