<div class="modal" id="callModal" tabindex="-1" aria-labelledby="callModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="callModalLabel">Telefonisch contact</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>

            <div class="modal-body pt-3 pb-3">
                Indien u liever telefonisch contact opneemt of uw vraag spoed heeft, belt u het nummer
                hieronder.<br/><br/>

                <h4>
                    <i class="fas fa-phone-alt"></i>&nbsp; 0800-{{ rand(1000,9999) }}
                </h4>
            </div>

            <div class="modal-footer">
                @if(! $minimal)
                    <a href="{{ route('ticket.create') }}" class="btn btn-primary btn-sm">
                        Ticket aanmaken
                    </a>
                @endif

                <button type="button" class="btn btn-secondary btn-sm" data-bs-dismiss="modal">
                    Sluiten
                </button>
            </div>
        </div>
    </div>
</div>
