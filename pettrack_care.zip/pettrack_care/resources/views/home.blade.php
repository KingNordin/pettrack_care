@extends('layouts.app')

@section('content')
    <div class="container-fluid">
        <div class="row">
            <div class="col-12 col-md-7">
                @include('components/intro', ['type' => 0])
            </div>

            <div class="col-12 col-md-4 offset-md-1">
                @include('components/auth/login')
            </div>
        </div>
    </div>


@endsection
