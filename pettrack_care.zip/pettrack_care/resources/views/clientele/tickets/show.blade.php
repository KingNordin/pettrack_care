@extends('layouts.app')

@section('content')
    <h3>"{{ $ticket->subject }}"</h3>
    <i>{{ $ticket->created_at->diffForHumans() }} ({{ $ticket->created_at->format('d-m-Y H:i') }}) ingezonden.</i>

    <div class="form-group mt-3">
        <label for="content">Naam:</label>
        <input class="form-control"
               id="content"
               readonly
               type="text"
               value="{{ $ticket->name }}"
               name="name">
    </div>

    <div class="form-group mt-3">
        <label for="content">E-mailadres:</label>
        <input class="form-control"
               id="content"
               readonly
               type="text"
               value="{{ $ticket->email }}"
               name="email">
    </div>

    <div class="form-group mt-3">
        <label for="content">Naam huisdier:</label>
        <input class="form-control"
               id="content"
               readonly
               type="text"
               value="{{ $ticket->pet_name }}"
               name="pet_name">
    </div>

    <div class="form-group mt-3">
        <label for="content">Categorie:</label>
        <input class="form-control"
               id="content"
               readonly
               type="text"
               value="{{ $ticket->category->name }}"
               name="category_name">
    </div>

    <div class="form-group mt-3">
        <label for="content">Omschrijving van uw vraag</label>
        <textarea class="form-control"
                  id="content"
                  readonly
                  rows="3"
                  name="content">{{ $ticket->content }}</textarea>
    </div>
@endsection

