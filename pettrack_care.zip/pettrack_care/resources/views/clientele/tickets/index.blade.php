
@extends('layouts.app')

@section('content')
    <h1>Mijn tickets ({{ count($tickets) }})</h1>

    @if (count($tickets) >= 1)
        <table class="table">
            <thead>
            <tr>
                <th>Onderwerp</th>
                <th>Naam huisdier</th>
                <th>Categorie</th>
                <th>Acties</th>
            </tr>
            </thead>
            <tbody>
            @foreach ($tickets as $ticket)
                <tr>
                    <th>{{ $ticket->subject }}</th>
                    <td>{{ $ticket->pet_name }}</td>
                    <td>{{ $ticket->category->name }}</td>
                    <td>
                        <a href="{{ route('clientele.tickets.show', ['ticket' => $ticket->id]) }}"
                           class="btn btn-primary btn-sm">
                            Openen
                        </a>
                    </td>
                </tr>
            @endforeach
            </tbody>
        </table>
    @else
        Je hebt nog geen tickets verzonden.
    @endif

@endsection


