@extends('layouts.app')

@section('content')
    <h1>Afspraak historie</h1>
    <p>
        Hieronder ziet u een lijst van vorige afspraken van {{ $appointments->first()->patient->name }}.
    </p>

    <div class="mt-5">
        @foreach($appointments as $appointment)
            <h3>{{ \Carbon\Carbon::parse($appointment->created_at)->diffForHumans() }}</h3>

            <div class="text-muted small mt-2">
                @foreach($appointment->statuses->reverse() as $index => $status)
                    &bull; {{ \Carbon\Carbon::parse($status->updated_at)->format("d M H:i") }} &mdash; {{ $status->description }}
                    {{ sprintf('(%d/%d)', ($index + 1), $appointment->expected_statuses) }}
                    <br/>
                @endforeach
            </div>

            <br/>
        @endforeach
    </div>

{{--<table class="table">--}}
{{--        <thead>--}}
{{--            <tr>--}}
{{--                <th scope="col">Patient</th>--}}
{{--                <th scope="col">Eigenaar/eigenaresse</th>--}}
{{--                <th scope="col">Ingepland op</th>--}}
{{--            </tr>--}}
{{--        </thead>--}}
{{--        <tbody>--}}
{{--            @foreach( $appointments as $appointment )--}}
{{--            <tr>--}}
{{--                <th scope="row">{{ $appointment->patient->name }}</th>--}}
{{--                <td>{{ $appointment->owner->name }}</td>--}}
{{--                <td>{{ $appointment->appointment_at }} ({{ \Carbon\Carbon::parse($appointment->appointment_at)->diffForHumans() }})</td>--}}
{{--            </tr>--}}
{{--            @endforeach--}}
{{--        </tbody>--}}
{{--    </table>--}}
@endsection
