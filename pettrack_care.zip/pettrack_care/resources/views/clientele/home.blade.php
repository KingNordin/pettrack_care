@extends('layouts.app')

@section('content')
    <h1>Mijn {{ count($pets) === 1 ? 'huisdier' : 'huisdieren' }} ({{ count($pets) }})</h1>
    <p>
        Op deze pagina vind je een overzicht van jouw geregistreerde huisdieren.
    </p>

    @if (count($pets) >= 1)
        <div class="container-fluid">
            <div class="row">
                @foreach ($pets as $pet)
                    <div class="card pet-card col-2">
                        <img src="https://eu.ui-avatars.com/api/?background=0d6efd&color=fff&name={{ $pet->name }}&length=1"
                             class="card-img-top image-pet"
                             alt="Avatar">
                        <div class="card-body">
                            <h5 class="card-title">{{ $pet->name }}</h5>
                            <p class="card-text">
                                <span class="text-muted">{{ $pet->breed }}</span><br>
                                Geb. {{ \Carbon\Carbon::parse($pet->date_of_birth)->format('d-m-Y') }}
                            </p>
                            <a href="{{ route('clientele.medication', ['id' => $pet->id]) }}" class="btn btn-success btn-sm">Medicatiedossier</a>
                            <a href="{{ route('clientele.appointments', ['id' => $pet->id]) }}" class="btn btn-primary btn-sm">Afspraak historie</a>
                        </div>
                    </div>
                </div>
            </div>
            @endforeach
            </div>
        </div>
    @else
        <div class="mt-5">
            Er staan nog geen huisdieren geregistreerd onder jouw naam. Als je denkt dat dit een fout is dan vragen wij je
            om <a href="{{ route('ticket.create') }}">contact</a> met ons op te nemen.
        </div>
    @endif
@endsection

