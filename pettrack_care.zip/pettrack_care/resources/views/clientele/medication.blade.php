@extends('layouts.app')
@section('content')
    <h1>Medicatiedossier</h1>
    <p>
        Hieronder ziet u een lijst van medicatieadvies die {{ $entries->first()->patient->name }} heeft ontvangen.
    </p>

    <div class="mt-5">
        @foreach($entries as $entry)
            <h3>{{ \Carbon\Carbon::parse($entry->created_at)->diffForHumans() }}</h3>
            <b title="{{ $entry->medicine->description }}">{{ $entry->medicine->name }}</b><br/>

            <p>
                {{ $entry->content }}
            </p>

            <br/>
        @endforeach
    </div>
@endsection
