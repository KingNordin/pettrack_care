


<?php $__env->startSection('content'); ?>
    <h1>Mijn tickets (<?php echo e(count($tickets)); ?>)</h1>

    <?php if(count($tickets) >= 1): ?>
        <table class="table">
            <thead>
            <tr>
                <th>Onderwerp</th>
                <th>Naam huisdier</th>
                <th>Categorie</th>
                <th>Acties</th>
            </tr>
            </thead>
            <tbody>
            <?php $__currentLoopData = $tickets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ticket): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <th><?php echo e($ticket->subject); ?></th>
                    <td><?php echo e($ticket->pet_name); ?></td>
                    <td><?php echo e($ticket->category->name); ?></td>
                    <td>
                        <a href="<?php echo e(route('clientele.tickets.show', ['ticket' => $ticket->id])); ?>"
                           class="btn btn-primary btn-sm">
                            Openen
                        </a>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    <?php else: ?>
        Je hebt nog geen tickets verzonden.
    <?php endif; ?>

<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\nordi\OneDrive\Documenten\pettrack_care\resources\views/clientele/tickets/index.blade.php ENDPATH**/ ?>