
<?php $__env->startSection('content'); ?>
    <?php if(\Session::has('message')): ?>
        <p class="alert <?php echo e(\Session::get('alert-class', 'alert-info')); ?>"><?php echo e(\Session::get('message')); ?></p>
    <?php endif; ?>

    <h1>Medicijnen</h1>

    <div class="mt-5">
        <a href="<?php echo e(route('medicine.show')); ?>" class="btn btn-primary">Medicijnen</a>
    </div>
    
    <div class="mt-5">
        <a href="<?php echo e(route('medicine.create')); ?>" class="btn btn-primary">Medicijnen aanmaken</a>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\nordi\OneDrive\Documenten\pettrack_care\resources\views/medicine/index.blade.php ENDPATH**/ ?>