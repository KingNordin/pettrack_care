

<?php $__env->startSection('content'); ?>
    <h1>Tickets</h1>

    <?php if(count($tickets) >= 1): ?>
    <table class="table">
        <thead>
            <tr>
                <th>&nbsp;</th>
                <th>Onderwerp</th>
                <th>Naam</th>
                <th>Categorie</th>
                <th>Acties</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $tickets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ticket): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr class="<?php echo e($ticket->is_read ? '' : ' '); ?>">
                    <td>
                        <?php if((bool) $ticket->is_read === false): ?>
                            <span class="pulse"></span>
                        <?php endif; ?>
                    </td>
                    <?php if((bool) $ticket->is_read === false): ?>
                        <th><?php echo e($ticket->subject); ?></th>
                    <?php else: ?>
                        <td><?php echo e($ticket->subject); ?></td>
                    <?php endif; ?>
                    <td><?php echo e($ticket->name); ?></td>
                    <td><?php echo e($ticket->category->name); ?></td>
                    <td>
                        <a href="<?php echo e(route('admin.tickets.show', ['ticket' => $ticket->id])); ?>"
                           class="btn btn-primary btn-sm">
                            Openen
                        </a>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
    <?php else: ?>
    <p>
        Er zijn nog geen vragen/opmerkingen opgestuurd door cliënten, echter zullen ze hier verschijnen zodra dat wel zo is.
    </p>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\nordi\OneDrive\Documenten\pettrack_care\resources\views/admin/ticket/index.blade.php ENDPATH**/ ?>