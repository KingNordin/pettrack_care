
<?php $__env->startSection('content'); ?>
    <?php if(\Session::has('message')): ?>
        <p class="alert alert-success"><?php echo e(\Session::get('message')); ?></p>
    <?php endif; ?>

    <div class="mt-5">
        <a href="<?php echo e(route('appointment.create')); ?>" class="btn btn-primary">Maak nieuwe afspraak</a>
    </div>
    <br>
<table class="table">
        <thead>
            <tr>
                <th scope="col">Patient</th>
                <th scope="col">Eigenaar/eigenaresse</th>
                <th scope="col">Verwachtte fases</th>
                <th scope="col">Ingepland op</th>
                <th scope="col">Acties</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $appointments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $appointment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <th scope="row"><?php echo e($appointment->patient->name); ?></th>
                <td><?php echo e($appointment->owner->name); ?></td>
                <td><?php echo e($appointment->expected_statuses); ?></td>
                <td><?php echo e($appointment->appointment_at); ?> (<?php echo e(\Carbon\Carbon::parse($appointment->appointment_at)->diffForHumans()); ?>)</td>
                <td>
                    <a href="<?php echo e(route('appointment.edit', ['appointment' => $appointment->id])); ?>" class="btn btn-primary btn-sm">
                        Aanpassen
                    </a>
                    <a href="<?php echo e(route('appointment.delete', ['id' => $appointment->id])); ?>" class="btn btn-danger btn-sm">
                        Verwijderen
                    </a>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\nordi\OneDrive\Documenten\pettrack_care\resources\views/appointment/show.blade.php ENDPATH**/ ?>