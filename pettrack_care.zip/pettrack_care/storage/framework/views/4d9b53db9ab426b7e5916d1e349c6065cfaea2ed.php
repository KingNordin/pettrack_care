
<?php $__env->startSection('content'); ?>
    <?php if($errors->any()): ?>
        <div class="alert alert-danger" role="alert">
            <strong>Er zijn één of meer fouten opgetreden:</strong><br/>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            &bull; <?php echo e($error); ?><br/>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    <?php endif; ?>

    <form action ="<?php echo e(route('medicine.store')); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <div class="form-group mt-3">
            <label for="name">Naam van het medicijn</label>
            <input type="text"
                   class="form-control"
                   id="patient_medicine"
                   placeholder="Naam van het medicijn"
                   name="patient_medicine">
        </div>
        <div class="form-group mt-3">
            <label for="name">Beschrijving van het medicijn</label>
            <input type="text"
                   class="form-control"
                   id="patient_medicine_desc"
                   placeholder="Vul hier de beschrijving in"
                   name="patient_medicine_desc">
        </div>
        <div class="form-group mt-3">
            <label for="name">Gebruik van het medicijn</label>
            <input type="text"
                   class="form-control"
                   id="patient_medicine_use"
                   placeholder="Vul hier het gebruik in"
                   name="patient_medicine_use">
        </div>
        <button type="submit" class="btn btn-primary mt-3">verzenden</button>
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\nordi\OneDrive\Documenten\pettrack_care\resources\views/medicine/create.blade.php ENDPATH**/ ?>