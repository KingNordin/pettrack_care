<div class="form-check mb-3">
    <?php if($settings->get('notifications_marketing') === 'on'): ?>
        <input class="form-check-input" type="checkbox" name="notifications_marketing" id="notifications_marketing" checked>
    <?php else: ?>
        <input class="form-check-input" type="checkbox" name="notifications_marketing" id="notifications_marketing">
    <?php endif; ?>
    <label class="form-check-label" for="notifications_marketing">
        Ik wil marketing e-mails ontvangen
    </label>
</div>

<div class="form-check">
    <?php if($settings->get('notifications_updates') === 'on'): ?>
        <input class="form-check-input" type="checkbox" name="notifications_updates" id="notifications_updates" checked>
    <?php else: ?>
        <input class="form-check-input" type="checkbox" name="notifications_updates" id="notifications_updates">
    <?php endif; ?>
    <label class="form-check-label" for="notifications_updates">
        Ik wil updates ontvangen over behandelingen van mijn huisdier(en)
    </label>
</div>
<?php /**PATH C:\Users\nordi\OneDrive\Documenten\pettrack_care\resources\views/settings/components/notifications.blade.php ENDPATH**/ ?>