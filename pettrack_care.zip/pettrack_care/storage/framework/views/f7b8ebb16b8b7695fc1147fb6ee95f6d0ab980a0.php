

<?php $__env->startSection('content'); ?>
    <h3>"<?php echo e($ticket->subject); ?>"</h3>
    <i><?php echo e($ticket->created_at->diffForHumans()); ?> (<?php echo e($ticket->created_at->format('d-m-Y H:i')); ?>) ingezonden.</i>

    <div class="form-group mt-3">
        <label for="content">Naam:</label>
        <input class="form-control"
               id="content"
               readonly
               type="text"
               value="<?php echo e($ticket->name); ?>"
               name="name">
    </div>

    <div class="form-group mt-3">
        <label for="content">E-mailadres:</label>
        <input class="form-control"
               id="content"
               readonly
               type="text"
               value="<?php echo e($ticket->email); ?>"
               name="email">
    </div>

    <div class="form-group mt-3">
        <label for="content">Naam huisdier:</label>
        <input class="form-control"
               id="content"
               readonly
               type="text"
               value="<?php echo e($ticket->pet_name); ?>"
               name="pet_name">
    </div>

    <div class="form-group mt-3">
        <label for="content">Categorie:</label>
        <input class="form-control"
               id="content"
               readonly
               type="text"
               value="<?php echo e($ticket->category->name); ?>"
               name="category_name">
    </div>

    <div class="form-group mt-3">
        <label for="content">Omschrijving van uw vraag</label>
        <textarea class="form-control"
                  id="content"
                  readonly
                  rows="3"
                  name="content"><?php echo e($ticket->content); ?></textarea>
    </div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\nordi\OneDrive\Documenten\pettrack_care\resources\views/clientele/tickets/show.blade.php ENDPATH**/ ?>