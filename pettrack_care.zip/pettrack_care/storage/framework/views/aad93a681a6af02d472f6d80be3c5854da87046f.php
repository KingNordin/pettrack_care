

<?php $__env->startSection('content'); ?>
    <h1>Mijn <?php echo e(count($pets) === 1 ? 'huisdier' : 'huisdieren'); ?> (<?php echo e(count($pets)); ?>)</h1>
    <p>
        Op deze pagina vind je een overzicht van jouw geregistreerde huisdieren.
    </p>

    <?php if(count($pets) >= 1): ?>
        <div class="container-fluid">
            <div class="row">
                <?php $__currentLoopData = $pets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pet): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="card pet-card col-2">
                        <img src="https://eu.ui-avatars.com/api/?background=0d6efd&color=fff&name=<?php echo e($pet->name); ?>&length=1"
                             class="card-img-top image-pet"
                             alt="Avatar">
                        <div class="card-body">
                            <h5 class="card-title"><?php echo e($pet->name); ?></h5>
                            <p class="card-text">
                                <span class="text-muted"><?php echo e($pet->breed); ?></span><br>
                                Geb. <?php echo e(\Carbon\Carbon::parse($pet->date_of_birth)->format('d-m-Y')); ?>

                            </p>
                            <a href="<?php echo e(route('clientele.medication', ['id' => $pet->id])); ?>" class="btn btn-success btn-sm">Medicatiedossier</a>
                            <a href="<?php echo e(route('clientele.appointments', ['id' => $pet->id])); ?>" class="btn btn-primary btn-sm">(Vorige) afspraken</a>
                        </div>
                    </div>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    <?php else: ?>
        <div class="mt-5">
            Er staan nog geen huisdieren geregistreerd onder jouw naam. Als je denkt dat dit een fout is dan vragen wij je
            om <a href="<?php echo e(route('ticket.create')); ?>">contact</a> met ons op te nemen.
        </div>
    <?php endif; ?>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\nordi\OneDrive\Documenten\pettrack_care\resources\views/clientele/home.blade.php ENDPATH**/ ?>