

<?php $__env->startSection('content'); ?>

    <?php if($errors->any()): ?>
        <div class="alert alert-danger" role="alert">
            <b>Er zijn één of meer fouten opgetreden:</b><br/>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            &bull; <?php echo e($error); ?><br/>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    <?php endif; ?>

    <form action ="<?php echo e(route('medicine.update', ['id' => $medicine->id])); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <div class="form-group mt-3">
            <label for="name">Naam van het medicijn</label>
            <input type="text"
                   class="form-control"
                   id="patient_medicine"
                   placeholder="Nieuwe naam van het medicijn"
                   name="patient_medicine"
                   value="<?php echo e($medicine->name); ?>">
        </div>

        <div class="form-group mt-3">
            <label for="description">Beschrijving van het medicijn</label>
            <input type="text"
                   class="form-control"
                   id="patient_medicine_desc"
                   placeholder="Nieuwe beschrijving van het medicijn"
                   name="patient_medicine_desc"
                   value="<?php echo e($medicine->description); ?>" >
        </div>
        <div class="form-group mt-3">
            <label for="usage">Gebruik van het medicijn</label>
            <input type="text"
                   class="form-control"
                   id="patient_medicine_use"
                   placeholder="Nieuw gebruik van het medicij"
                   name="patient_medicine_use"
                   value="<?php echo e($medicine->usage); ?>">
        </div>
        <button type="submit" class="btn btn-primary mt-3">Verzenden</button>
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\nordi\OneDrive\Documenten\pettrack_care\resources\views/medicine/edit.blade.php ENDPATH**/ ?>