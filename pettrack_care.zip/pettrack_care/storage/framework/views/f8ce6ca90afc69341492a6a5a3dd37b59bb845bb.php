
<?php $__env->startSection('content'); ?>
<?php if($errors->any()): ?>
        <div class="alert alert-danger" role="alert">
            <strong>Er zijn één of meer fouten opgetreden:</strong><br/>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                &bull; <?php echo e($error); ?><br/>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
<?php endif; ?>

<form action ="<?php echo e(route('appointment.store')); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <div class="form-group mt-3">
            <label for="name">Patient</label>

            <select name="patient_id" class="form-select mt-1">
                <option disabled selected>Selecteer een patient..</option>
                <?php $__currentLoopData = $patients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $patient): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($patient->id); ?>"><?php echo e(sprintf('%s - %s van %s (%s)', $patient->name, $patient->breed, $patient->owner->name, $patient->owner->email)); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>

        <div class="form-group mt-3">
            <label for="name">Eigenaar/eigenaresse</label>

            <select name="owner_id" class="form-select mt-1">
                <option disabled selected>Selecteer een gebruiker..</option>
                <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($user->id); ?>"><?php echo e(sprintf('%s (%s)', $user->name, $user->email)); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>

        <div class="form-group mt-3">
            <label for="status">Verwacht aantal fases</label>

            <input type="number"
                   min="0"
                   max="20"
                   value="3"
                   class="form-control mt-1"
                   id="expected_statuses"
                   placeholder="Verwachtte status"
                   name="expected_statuses">
        </div>

        <div class="form-group mt-3">
            <label for="time">Tijd van de afspraak</label>

            <input type="text"
                   class="form-control mt-1"
                   id="appointment_at"
                   placeholder="Tijd van de afspraak"
                   name="appointment_at">
        </div>
        <button type="submit" class="btn btn-primary mt-3">Verzenden</button>
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\nordi\OneDrive\Documenten\pettrack_care\resources\views/appointment/create.blade.php ENDPATH**/ ?>