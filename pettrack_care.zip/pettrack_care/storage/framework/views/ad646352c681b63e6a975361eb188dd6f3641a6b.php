<div class="mt-3 <?php echo e($type === 1 ? 'header-image' : 'secondary header-image'); ?>"></div>

<h3>PetTrack&Care biedt die speciale verbinding die je mag verwachten van een dierenarts.</h3>

<p class="mt-3">
    Via de PetTrack&Care applicatie kunt u gemakkelijk de actuele status van behandelingen van uw huisdier
    bijhouden, vorige behandelingen bekijken, het medicatiedossier inzien en meer. Door gebruik te maken
    van deze applicatie verbeter je de communicatie tussen jou en de dierenarts, hoef je minder snel contact
    op te nemen én kun je makkelijk inzage krijgen in dossiers die je normaliter via de post opgestuurd
    zou moeten krijgen.
</p>
<?php /**PATH C:\Users\nordi\OneDrive\Documenten\pettrack_care\resources\views/components/intro.blade.php ENDPATH**/ ?>