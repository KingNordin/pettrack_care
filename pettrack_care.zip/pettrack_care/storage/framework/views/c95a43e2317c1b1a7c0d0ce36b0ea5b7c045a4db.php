

<?php $__env->startSection('content'); ?>

    <h1>Vraag stellen aan de praktijk</h1>
    <div class="alert alert-warning" role="alert">
        <i class="fas fa-exclamation-triangle"></i>&nbsp;
        Betreft uw vraag een noodsituatie?
        <a href="#" class="text-dark" data-bs-toggle="modal" data-bs-target="#callModal">Klik dan hier</a> om de praktijk te bellen.
    </div>

    <?php echo $__env->make('components/call-modal', ['minimal' => true], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <?php if($errors->any()): ?>
        <div class="alert alert-danger">
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>

    <form action ="<?php echo e(route('ticket.store')); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <div class="form-group">
            <label for="name">Naam</label>
            <input type="text"
                   class="form-control"
                   id="name"
                   <?php echo e(auth()->check() ? 'readonly' : ''); ?>

                   placeholder="Uw naam"
                   name="name"
                   value="<?php echo e(auth()->check() ? auth()->user()->name : old('name', $appointment !== null ? $appointment->owner->name : null)); ?>">
            <?php if(auth()->guard()->check()): ?>
                <small class="text-muted">Automatisch ingevuld omdat je bent ingelogd.</small>
            <?php endif; ?>
        </div>

        <div class="form-group mt-3">
            <label for="email">E-mailadres</label>
            <input type="email"
                   class="form-control"
                   id="email"
                   <?php echo e(auth()->check() ? 'readonly' : ''); ?>

                   aria-describedby="emailHelp"
                   placeholder="Uw e-mailadres"
                   name="email"
                   value="<?php echo e(auth()->check() ? auth()->user()->email : old('email', $appointment !== null ? $appointment->owner->email : null)); ?>">
            <?php if(auth()->guard()->check()): ?>
                <small class="text-muted">Automatisch ingevuld omdat je bent ingelogd.</small>
            <?php endif; ?>
        </div>

        <div class="form-group mt-3">
            <label for="animal">Dier in kwestie (indien toepasselijk aan uw vraag)</label>
            <input type="text"
                   class="form-control"
                   id="animal"
                   placeholder="De naam van uw huisdier"
                   name="pet_name"
                   value="<?php echo e(old('pet_name', $appointment !== null ? $appointment->patient->name : null)); ?>">
        </div>

        <div class="form-group mt-3">
            <label for="category">Categorie</label>
            <div class="input-group mb-3">
                <select class="form-select"
                        id="category"
                        name="category_id">
                    <option selected disabled>Selecteer categorie..</option>
                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if(old('category_id') == $category->id): ?>
                            <option value="<?php echo e($category->id); ?>" selected><?php echo e($category->name); ?></option>
                        <?php else: ?>
                            <option value="<?php echo e($category->id); ?>"><?php echo e($category->name); ?></option>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
        </div>

        <div class="form-group mt-3">
            <label for="subject">Onderwerp</label>
            <input type="text"
                   class="form-control"
                   id="subject"
                   placeholder="Het onderwerp van uw vraag"
                   name="subject"
                   value="<?php echo e(old('subject')); ?>">
        </div>

        <div class="form-group mt-3">
            <label for="content">Omschrijving van uw vraag</label>
            <textarea class="form-control"
                      id="content"
                      rows="3"
                      name="content"><?php echo e(old('content')); ?></textarea>
        </div>

        <button type="submit" class="btn btn-primary mt-3">Verzenden</button>
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\nordi\OneDrive\Documenten\pettrack_care\resources\views/ticket/create.blade.php ENDPATH**/ ?>