

<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row">
            <div class="col-xl-1 col-lg-4 col-sm-12">
                <img src="https://thiscatdoesnotexist.com/"
                     class="rounded"
                     width="80"
                     height="80"
                     alt="Picture of a pet">
            </div>
            <div class="col-xl-9 col-lg-4 col-sm-12 mt-3 mt-lg-0">
                <h5><?php echo e($appointment->patient->name); ?></h5>
                <div><?php echo e($appointment->patient->breed); ?></div>
                <div>
                    <?php echo e(\Carbon\Carbon::parse($appointment->patient->date_of_birth)->diffInYears()); ?> jaar
                    (<?php echo e(\Carbon\Carbon::parse($appointment->patient->date_of_birth)->format("d M. 'y")); ?>)
                </div>
            </div>
            <div class="col-xl-2 col-lg-4 col-sm-12 text-lg-end text-start mt-3 mt-lg-0">
                <h5>
                    <?php echo e($appointment->owner->name); ?>

                </h5>

                <div>
                    <?php echo e(sprintf('%s %d%s', $appointment->owner->street, $appointment->owner->house_number, $appointment->owner->addition)); ?>

                </div>
                <div>
                    <?php echo e(sprintf('%s %s', $appointment->owner->zipcode, $appointment->owner->city)); ?>

                </div>
            </div>
        </div>
    </div>

    <div class="card mt-5">
        <div class="form p-4">
            <label for="customRange1" class="form-label">
                <h5><?php echo e(sprintf('Fase %d van %d', count($appointment->statuses), $appointment->expected_statuses)); ?></h5>
                <?php echo e($appointment->statuses->last()->description ?? ''); ?>

            </label>

            <div class="progress">
                <div class="progress-bar <?php echo e(count($appointment->statuses) < $appointment->expected_statuses ? 'progress-bar-striped progress-bar-animated' : ''); ?>"
                     role="progressbar"
                     style="width: <?php echo e(count($appointment->statuses) / $appointment->expected_statuses * 100); ?>%"></div>
            </div>

            <div class="text-muted small mt-2">
                <?php $__currentLoopData = $appointment->statuses->reverse(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $status): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    &bull; <?php echo e(\Carbon\Carbon::parse($status->updated_at)->format("d M H:i")); ?> &mdash; <?php echo e($status->description); ?>

                    <?php echo e(sprintf('(%d/%d)', ($index + 1), $appointment->expected_statuses)); ?>

                    <br/>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>

            <hr>

            <div class="pt-3 pb-3">
                <h3>(Medisch) Advies voor ná de behandeling</h3>
                <div class="mt-3">
                    <?php $__currentLoopData = $appointment->aftercare; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div>
                            <p>&bull; <?php echo e($item->content); ?></p>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>

            <hr>

            <div>
                <p>
                    Heeft u nog vragen over de behandeling? Dan kunt u altijd contact met ons opnemen. Kies één van de
                    contactmogelijkheden hieronder.
                </p>

                <a href="<?php echo e(route("ticket.create", ["code" => $appointment->code->code, "zipcode" => $appointment->owner->zipcode])); ?>" class="btn btn-primary">Vraag stellen</a>
                <a class="btn btn-outline-primary" data-bs-toggle="modal" data-bs-target="#callModal">
                    Telefonisch contact opnemen
                </a>

                <?php echo $__env->make('components/call-modal', ['minimal' => false], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\nordi\OneDrive\Documenten\pettrack_care\resources\views/tracking/show.blade.php ENDPATH**/ ?>