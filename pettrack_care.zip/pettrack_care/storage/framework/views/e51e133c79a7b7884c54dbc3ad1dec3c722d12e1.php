

<?php $__env->startSection('content'); ?>

<?php if($errors->any()): ?>
        <div class="alert alert-danger" role="alert">
            <b>Er zijn één of meer fouten opgetreden:</b><br/>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                &bull; <?php echo e($error); ?><br/>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
<?php endif; ?>

<form action ="<?php echo e(route('appointment.update', ['id' => $appointment->id])); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <div class="form-group mt-3">
            <label for="status">Verwachtte status</label>
            <input type="text"
                   class="form-control"
                   id="expected_statuses"
                   placeholder="Verwachtte status"
                   name="expected_statuses"
                   value="<?php echo e($appointment->expected_statuses); ?>">
        </div>
        
        <div class="form-group mt-3">
            <label for="time">Tijd van de afspraak</label>
            <input type="text"
                   class="form-control"
                   id="appointment_at"
                   placeholder="Tijd van de afspraak"
                   name="appointment_at"
                   value="<?php echo e($appointment->appointment_at); ?>">
        </div>
        <button type="submit" class="btn btn-primary mt-3">Verzenden</button>
    </form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\nordi\OneDrive\Documenten\pettrack_care\resources\views/appointment/edit.blade.php ENDPATH**/ ?>