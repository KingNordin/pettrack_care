

<?php $__env->startSection('content'); ?>
    <h1>Pain</h1>
    <div class="mt-5">
        <a href="<?php echo e(route('planning.create')); ?>" class="btn btn-primary">Planning maken</a>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\nordi\OneDrive\Documenten\pettrack_care\resources\views/planning/index.blade.php ENDPATH**/ ?>