
<?php $__env->startSection('content'); ?>
    

    <div class="mt-5">
        <a href="<?php echo e(route('appointment.create')); ?>" class="btn btn-primary">Maak planning</a>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\nordi\OneDrive\Documenten\pettrack_care\resources\views/appointment/index.blade.php ENDPATH**/ ?>