<div class="form-group">

    <div class="row">
        <div class="col-12 col-md-4">

            <div class="mb-3">
                <label for="nameField" class="form-label">Naam</label>
                <input type="email" class="form-control" id="nameField" disabled name="name" value="<?php echo e(auth()->user()->name); ?>">
            </div>

            <div class="mb-3">
                <label for="emailField" class="form-label">Email address</label>
                <input type="email" class="form-control" id="emailField" disabled value="<?php echo e(auth()->user()->email); ?>">
            </div>

        </div>
    </div>

</div>
<?php /**PATH C:\Users\nordi\OneDrive\Documenten\pettrack_care\resources\views/settings/components/profile_settings.blade.php ENDPATH**/ ?>