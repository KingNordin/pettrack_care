
<?php $__env->startSection('content'); ?>
<table class="table">
        <thead>
            <tr>
                <th scope="col">Naam medicijn</th>
                <th scope="col">Beschrijving</th>
                <th scope="col">Dosering</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $medications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $medication): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <th scope="row"><?php echo e($medication->medicine->name); ?></th>
                <td><?php echo e($medication->medicine->description); ?></td>
                <td><?php echo e($medication->medicine->usage); ?></td>
           </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\nordi\OneDrive\Documenten\pettrack_care\resources\views/clientele/medication.blade.php ENDPATH**/ ?>