
<?php $__env->startSection('content'); ?>
    <?php if(\Session::has('message')): ?>
        <p class="alert alert-success"><?php echo e(\Session::get('message')); ?></p>
    <?php endif; ?>

    <div class="mt-5">
        <a href="<?php echo e(route('medicine.create')); ?>" class="btn btn-primary">Medicijnen aanmaken</a>
    </div>
    <br>
<table class="table">
        <thead>
            <tr>
                <th scope="col">Medicijn</th>
                <th scope="col">Beschrijving</th>
                <th scope="col">Dosering</th>
                <th scope="col">Acties</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $medicines; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $medicine): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <th scope="row"><?php echo e($medicine->name); ?></th>
                <td><?php echo e($medicine->description); ?></td>
                <td><?php echo e($medicine->usage); ?></td>
                <td>
                    <a href="<?php echo e(route('medicine.edit', ['medicine' => $medicine->id])); ?>" class="btn btn-primary btn-sm">
                        Aanpassen
                    </a>
                    <a href="<?php echo e(route('medicine.delete', ['id' => $medicine->id])); ?>" class="btn btn-danger btn-sm">
                        Verwijderen
                    </a>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\nordi\OneDrive\Documenten\pettrack_care\resources\views/medicine/show.blade.php ENDPATH**/ ?>