

<?php $__env->startSection('content'); ?>
    <h1>Behandeling volgen</h1>

    <?php if($errors->any()): ?>
        <div class="alert alert-danger" role="alert">
            <b>Er zijn één of meer fouten opgetreden:</b><br/>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                &bull; <?php echo e($error); ?><br/>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    <?php endif; ?>

    <form class="mt-3" action="<?php echo e(route('track.follow')); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <div class="mb-3">
            <label for="code" class="form-label">Code van de afspraak</label>
            <input type="text"
                   class="form-control"
                   id="code"
                   name="code"
                   maxlength="19"
                   value="<?php echo e(old('code')); ?>"
                   placeholder="Bijv. 6573-2345-5643-2684">

            <div class="form-text">Deze code ontvangt u maximaal 24 uur vóór de behandeling van uw huisdier.</div>
        </div>

        <div class="mb-3">
            <label for="zipcode" class="form-label">Postcode eigenaar/eigenaresse</label>
            <input type="text"
                   class="form-control"
                   id="zipcode"
                   name="zipcode"
                   maxlength="7"
                   value="<?php echo e(old('zipcode')); ?>"
                   placeholder="Bijv. 1059 EP">
        </div>

        <button type="submit" class="btn btn-primary">Volgen</button>
    </form>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\nordi\OneDrive\Documenten\pettrack_care\resources\views/tracking/index.blade.php ENDPATH**/ ?>