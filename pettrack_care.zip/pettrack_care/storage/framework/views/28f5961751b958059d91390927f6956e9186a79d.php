

<?php $__env->startSection('content'); ?>
<table class="table">
        <thead>
            <tr>
                <th scope="col">Patient</th>
                <th scope="col">Eigenaar/eigenaresse</th>
                <th scope="col">Verwachtte fases</th>
                <th scope="col">Ingepland op</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $appointments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $appointment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <th scope="row"><?php echo e($appointment->patient->name); ?></th>
                <td><?php echo e($appointment->owner->name); ?></td>
                <td><?php echo e($appointment->expected_statuses); ?></td>
                <td><?php echo e($appointment->appointment_at); ?> (<?php echo e(\Carbon\Carbon::parse($appointment->appointment_at)->diffForHumans()); ?>)</td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\nordi\OneDrive\Documenten\pettrack_care\resources\views/clientele/appointments.blade.php ENDPATH**/ ?>