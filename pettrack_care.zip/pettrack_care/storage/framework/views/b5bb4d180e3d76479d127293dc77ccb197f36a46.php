

<?php $__env->startSection('content'); ?>
    <h1>Instellingen</h1>

    <div class="mt-3">

        <div class="row">
            <div class="col-12 col-md-9">
                <ul class="nav nav-pills mb-3" id="pills-tab" role="tablist">
                    <li class="nav-item" role="presentation">
                        <button class="nav-link btn active"
                                id="pills-profile-tab"
                                data-bs-toggle="pill"
                                data-bs-target="#pills-profile"
                                type="button"
                                role="tab"
                                aria-controls="pills-profile"
                                aria-selected="true">Profielgegevens</button>
                    </li>

                    <li class="nav-item" role="presentation">
                        <button class="nav-link btn"
                                id="pills-notifications-tab"
                                data-bs-toggle="pill"
                                data-bs-target="#pills-notifications"
                                type="button"
                                role="tab"
                                aria-controls="pills-notifications"
                                aria-selected="false">Notificaties</button>
                    </li>
                </ul>
            </div>

            <div class="col-12 col-md-3">
                <li class="nav-item btn btn-success" onclick="event.preventDefault(); document.getElementById('settings-form').submit();">
                    Instellingen opslaan
                </li>
            </div>
        </div>

        <form action="<?php echo e(route('settings.update')); ?>" method="POST" id="settings-form">
            <?php echo csrf_field(); ?>

            <div class="tab-content mt-3" id="pills-tabContent">
                <div class="tab-pane show active" id="pills-profile" role="tabpanel" aria-labelledby="pills-profile-tab">
                    <?php echo $__env->make('settings.components.profile_settings', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>

                <div class="tab-pane" id="pills-notifications" role="tabpanel" aria-labelledby="pills-notifications-tab">
                    <?php echo $__env->make('settings.components.notifications', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>
            </div>
        </form>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\nordi\OneDrive\Documenten\pettrack_care\resources\views/settings/index.blade.php ENDPATH**/ ?>