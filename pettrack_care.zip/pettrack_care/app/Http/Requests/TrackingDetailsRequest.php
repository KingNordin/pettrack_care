<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class TrackingDetailsRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Prepare for validation
     */
    protected function prepareForValidation()
    {
        foreach (['code', 'zipcode'] as $variable) {
            $this->merge([
                $variable => strtoupper(preg_replace('/\s+/', '', $this->get($variable)))
            ]);
        }
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            'code'    => 'required|size:19|alpha_dash',
            'zipcode' => 'required|size:6|regex:/\d{4}[A-Z]{2}/'
        ];
    }
}
