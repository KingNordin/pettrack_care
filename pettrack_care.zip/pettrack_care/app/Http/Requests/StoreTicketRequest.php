<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class StoreTicketRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            'name'        => 'required|string|max:255|min:2',
            'email'       => 'required|string|max:255|email:rfc,dns|min:3',
            'pet_name'    => 'sometimes|nullable|string|max:255|min:2',
            'category_id' => 'required|integer|exists:ticket_categories,id',
            'subject'     => 'required|string|max:255|min:2',
            'content'     => 'required|string|max:65535|min:2',
        ];
    }
}
