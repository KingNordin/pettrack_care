<?php

namespace App\Http\Middleware;

use App\Providers\RouteServiceProvider;
use Closure;
use Illuminate\Http\Request;

/**
 * Class VerifyAdministratorStatus
 * @package App\Http\Middleware
 */
class VerifyAdministratorStatus
{
    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure  $next
     * @return mixed
     */
    public function handle(Request $request, Closure $next)
    {
        if (auth()->user() && !! auth()->user()->is_admin === true) {
            return $next($request);
        } else if (auth()->user() && !! auth()->user()->is_admin === false) {
            return redirect(RouteServiceProvider::HOME_CLIENTELE);
        }

        return redirect(route('home'));
    }
}
