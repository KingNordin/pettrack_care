<?php
namespace App\Http\Controllers;

use App\Http\Requests\MedicineRequest;
use App\Models\Medicine;
use Illuminate\Http\Request;


class MedicineController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //index was not necessary
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('medicine.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(MedicineRequest $request)
    {
        $medicine = new Medicine();
        $medicine->name = $request->get('patient_medicine');
        $medicine->description = $request->get('patient_medicine_desc');
        $medicine->usage = $request->get('patient_medicine_use');
        $medicine->save();

        \Session::flash('message', 'Het medicijn is opgeslagen');
        \Session::flash('alert-class', 'alert-success');

        return redirect()->route('medicine.show', ['medicines']);
    }

    /**
     * Display the specified resource.
     *
     * @param Request $requests
     * @return \Illuminate\Contracts\Foundation\Application|\Illuminate\Contracts\View\Factory|\Illuminate\Contracts\View\View|\Illuminate\Http\Response
     */
    public function show()
    {
        $medicines = Medicine::get();
        return view('medicine.show', compact('medicines'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit(Medicine $medicine)
    {
        return view('medicine.edit', compact('medicine'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(MedicineRequest $request, $id)
    {
        $medicines = Medicine::findOrFail($id);
        $medicines->name = $request->get('patient_medicine');
        $medicines->description = $request->get('patient_medicine_desc');
        $medicines->usage = $request->get('patient_medicine_use');
        $medicines->save();

        \Session::flash('message', 'Het medicijn is bijgewerkt');
        \Session::flash('alert-class', 'alert-success');

        return redirect()->route('medicine.show');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $medicines = Medicine::findOrFail($id);
        $medicines->delete();

        \Session::flash('message', 'Het medicijn is verwijderd.');
        \Session::flash('alert-class', 'alert-success');

        return redirect()->route('medicine.show');
    }
}
