<?php

namespace App\Http\Controllers\Clientele;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Patient;
use App\Models\Appointment;
use App\Models\AftercareRecord;

/**
 * Class HomeController
 * @package App\Http\Controllers\Clientele
 */
class HomeController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Contracts\Foundation\Application|\Illuminate\Contracts\View\Factory|\Illuminate\Contracts\View\View|\Illuminate\Http\Response
    */
    public function index()
    {
        $pets = auth()->user()->pets()->get();
        return view('clientele.home', compact('pets'));
    }

    /**
     * Gets the appointments based on the patient id and owner id
     *
     * @param  \Illuminate\Http\Request  $request
     */
    public function previousAppointments(Request $request)
    {
        $appointments = Appointment::where('patient_id', $request->id)
                                   ->with(['statuses'])
                                   ->where('owner_id', auth()->user()->id)
                                   ->get();

        return view('clientele.appointments', compact('appointments'));
    }

    /**
     * Gets the after care based on the patient id and owner id
     *
     * @param  \Illuminate\Http\Request  $request
     */
    public function medication(Request $request)
    {
        $entries = AftercareRecord::get()->where('patient_id', $request->id)->where('owner_id', auth()->user()->id);

        return view('clientele.medication', compact('entries'));
    }
}
