<?php

namespace App\Http\Controllers;

use App\Models\Setting;
use Illuminate\Http\Request;

class SettingsController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
    }

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Contracts\Foundation\Application|\Illuminate\Contracts\View\Factory|\Illuminate\Contracts\View\View|\Illuminate\Http\Response
     */
    public function index()
    {
        $user_settings = auth()->user()->settings;
        $settings = collect(config('settings.defaults'));

        // Overwrite defaults by request values (if given)
        foreach ($settings as $key => $default) {
            $conditional_find = $user_settings->where('key', $key);
            $settings->put($key, $conditional_find->count() >= 1 ? $conditional_find->first()->value : $default);
        }

        return view('settings.index', compact('settings'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request)
    {
        $settings = $request->all();
        unset($settings['_token']);

        $all_settings = config('settings.defaults');

        // Overwrite defaults by request values (if given)
        foreach ($all_settings as $index => $setting) {
            $all_settings[$index] = $request->get($index, $setting);
        }

        Setting::where('user_id',auth()->user()->id )->delete();

        foreach ($all_settings as $key => $value)
        {
            Setting::insert([
                'user_id' => auth()->user()->id,
                'key' => $key,
                'value' => $value
            ]);
        }

        return redirect()->refresh();
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
