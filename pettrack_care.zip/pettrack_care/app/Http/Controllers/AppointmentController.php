<?php

namespace App\Http\Controllers;

use App\Http\Requests\AppointmentRequest;
use App\Models\Appointment;
use App\Models\Patient;
use App\Models\AftercareRecord;
use Illuminate\Http\Request;
use App\models\User;
use Redirect;

class AppointmentController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //index was not necessary 
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Contracts\Foundation\Application|\Illuminate\Contracts\View\Factory|\Illuminate\Contracts\View\View|\Illuminate\Http\Response
     */
    public function create()
    {
        $users = User::select('id', 'name', 'email')->where('is_admin', false)->get();
        $patients = Patient::with(['owner'])->get();

        return view('appointment.create', compact('users', 'patients'));
    }

     /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Contracts\Foundation\Application|\Illuminate\Http\RedirectResponse|\Illuminate\Http\Response|\Illuminate\Routing\Redirector
     */
    public function store(AppointmentRequest $request)
    {
        $owner = User::find($request->get('owner_id'));
        $patient = Patient::find($request->get('patient_id'));

        if ($owner->id !== $patient->owner_id) {
            abort(401, 'Patient does not belong to the given owner.');
        }

        $appointment = new Appointment();
        $appointment->patient_id = $request->get('patient_id');
        $appointment->owner_id = $request->get('owner_id');
        $appointment->expected_statuses = $request->get('expected_statuses');
        $appointment->appointment_at = $request->get('appointment_at');
        $appointment->save();

        \Session::flash('message', 'De afspraak is ingepland!');
        \Session::flash('alert-class', 'alert-success');

        return redirect()->route('appointment.show', ['appointments','aftercareMeds']); 
    }

    /**
     * Display the specified resource.
     *
     * @param Request $requests
     * @return \Illuminate\Contracts\Foundation\Application|\Illuminate\Contracts\View\Factory|\Illuminate\Contracts\View\View|\Illuminate\Http\Response
     */
    public function show()
    {
        $appointments = Appointment::get();
        $aftercareMeds = AftercareRecord::get();
        
        return view('appointment.show', compact(['appointments','aftercareMeds']));
    }

    public function edit(Appointment $appointment)
    {
        return view('appointment.edit', compact('appointment'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $appointments = Appointment::findOrFail($id);
        $appointments->expected_statuses = $request->get('expected_statuses');
        $appointments->appointment_at = $request->get('appointment_at');
        $appointments->save();

        \Session::flash('message', 'De afspraak is bewerkt!');
        \Session::flash('alert-class', 'alert-success');

        return redirect()->route('appointment.show');
    }

    public function destroy($id)
    {
        $appointments = Appointment::findOrFail($id);
        $appointments->delete();

        \Session::flash('message', 'De afspraak is verwijderd!');
        \Session::flash('alert-class', 'alert-success');

        return redirect()->route('appointment.show'); 
    }
}
