<?php

namespace App\Http\Controllers;

use App\Http\Requests\StoreTicketRequest;
use App\Models\Appointment;
use App\Models\TicketCategory;
use App\Models\Ticket;
use Illuminate\Http\Request;
use Illuminate\Session\Store;

class TicketController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @param Request $request
     * @return \Illuminate\Contracts\Foundation\Application|\Illuminate\Contracts\View\Factory|\Illuminate\Contracts\View\View|\Illuminate\Http\Response
     */
    public function create(Request $request)
    {
        $appointment = null;

        if ($request->has('code') && $request->has('zipcode')) {
            $appointment = Appointment::whereHas('code', function ($query) use ($request) {
                return $query->where('tracking_codes.code', '=', $request->get('code'));
            })->whereHas('owner', function ($query) use ($request) {
                return $query->where('users.zipcode', '=', $request->get('zipcode'));
            })->with([
                'patient',
                'owner',
            ])->firstOrFail();
        }

        $categories = TicketCategory::select('id', 'name')->get();

        return view('ticket.create', compact('categories', 'appointment'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param StoreTicketRequest $request
     * @return \Illuminate\Contracts\Foundation\Application|\Illuminate\Contracts\View\Factory|\Illuminate\Contracts\View\View|\Illuminate\Http\Response
     */
    public function store(StoreTicketRequest $request)
    {
        $ticket = new Ticket();

        $ticket->name = auth()->check() ? auth()->user()->name : $request->get('name');
        $ticket->email = auth()->check() ? auth()->user()->email : $request->get('email');
        $ticket->pet_name = $request->get('pet_name');
        $ticket->category_id = $request->get('category_id');
        $ticket->subject = $request->get('subject');
        $ticket->content = $request->get('content');
        $ticket->owner_id = auth()->check() ? auth()->user()->id : null;

        $ticket->save();

        return view('ticket.store');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
