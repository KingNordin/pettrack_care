<?php
namespace App\Http\Controllers;

use App\Http\Requests\AftercareRequest;
use App\Models\AftercareRecord;
use App\Models\Appointment;
use App\Models\Patient;
use App\Models\Medicine;
use App\Models\User;
use Illuminate\Http\Request;
use Redirect;
use App\models\Owner;
class AftercareController extends Controller
{

    public function index()
    {

        return view('aftercare.index');

    }

    public function create()
    {
        $medicine = Medicine::get();
        $ownerId  = User::get();
        $patientId = Patient::get();
        $appointment = Appointment::get();
        return view('aftercare.create', compact(['medicine','ownerId','patientId', 'appointment']));
    }

    public function store(AftercareRequest $request)
    {
        $ownerId = User::where('name', $request->get('eigenaar'))->firstOrFail();
        $patientId = Patient::where('name', $request->get('huisdier'))->where('owner_id', $ownerId->id)->firstOrFail();
        $aftercare = new AftercareRecord();
        $medicine = Medicine::where('name', $request->get('medicijn'))->firstOrFail();


        $aftercare->patient_id = $patientId->id;
        $aftercare->owner_id = $ownerId->id;
        $aftercare->appointment_id =$request->get('afspraak');
        $aftercare->medicine_id = $medicine->id;
        $aftercare->content = $request->get('medicijn');


        $aftercare->save();

        return Redirect::to('aftercare');
    }
    public function show()
    {

        $aftercare = AftercareRecord::get();
        $patientId = Patient::get();
        return view('aftercare.show', compact('aftercare','patientId'));

    }

}
