<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateAftercareRecordsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('appointment_aftercare', function (Blueprint $table) {
            $table->id();

            $table->text('content');

            $table->unsignedBigInteger('appointment_id');
            $table->foreign('appointment_id')
                  ->references('id')
                  ->on('appointments');

            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('aftercare_records');
    }
}
