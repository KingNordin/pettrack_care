<?php

namespace Database\Seeders;

use App\Models\AftercareRecord;
use App\Models\Appointment;
use App\Models\AppointmentStatus;
use App\Models\Owner;
use App\Models\Patient;
use App\Models\TrackingCode;
use App\Models\User;
use Faker\Factory;
use Illuminate\Database\Seeder;
use App\Models\Medicine;

class TestAppointmentSeeder extends Seeder
{
    /** @var $faker Faker Factory */
    private $faker;

    public function __construct()
    {
        $this->faker = Factory::create(config('app.faker_locale'));
    }

    /**
     * Seed the application's database.
     *
     * @return void
     */
    public function run()
    {
        /**
         * TODO: Use Factories (https://laravel.com/docs/8.x/database-testing#generating-factories)
         */
        // Create owner
        $owner = new User();

        $owner->name         = $this->faker->firstName;
        $owner->email        = $this->faker->email;
        $owner->password     = bcrypt($this->faker->password);
        $owner->zipcode      = strtoupper($this->faker->lexify(rand(1000,5000) . '??'));
        $owner->street       = $this->faker->streetName;
        $owner->house_number = rand(10, 50);
        $owner->city         = $this->faker->city;

        $owner->save();

        // Create patient
        $patient = new Patient();

        $patient->name          = $this->faker->firstName;
        $patient->breed         = 'Duitse herder';
        $patient->owner_id      = $owner->id;
        $patient->date_of_birth = $this->faker->dateTimeThisDecade;

        $patient->save();

        // Create appointment
        $appointment = new Appointment();

        $appointment->patient_id        = $patient->id;
        $appointment->owner_id          = $owner->id;
        $appointment->expected_statuses = 3;
        $appointment->appointment_at    = $this->faker->dateTimeThisMonth;

        $appointment->save();

        // Create medicine
        $medicine = new Medicine();

        $medicine->name         = $this->faker->bloodType;
        $medicine->description  = $this->faker->text;
        $medicine->usage         = $this->faker->bloodType;

        $medicine->save();

        // Create status record
        $status = new AppointmentStatus();

        $status->description = 'Voorbereidingen';
        $status->appointment_id = $appointment->id;

        $status->save();

        // Create tracking code
        $tracking_code = new TrackingCode();

        $tracking_code->code           = $this->faker->numerify('####-####-####-####');
        $tracking_code->appointment_id = $appointment->id;

        $tracking_code->save();

        // Create aftercare record
        $aftercare_record = new AftercareRecord();

        $aftercare_record->content        = $this->faker->text;
        $aftercare_record->appointment_id = $appointment->id;
        $aftercare_record->medicine_id    = $medicine->id;
        $aftercare_record->patient_id    = $patient->id;
        $aftercare_record->owner_id    = $owner->id;

        $aftercare_record->save();
    }
}
