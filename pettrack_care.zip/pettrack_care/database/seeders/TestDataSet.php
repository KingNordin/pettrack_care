<?php

namespace Database\Seeders;

use App\Models\AftercareRecord;
use App\Models\Appointment;
use App\Models\AppointmentStatus;
use App\Models\Medicine;
use App\Models\Patient;
use App\Models\TrackingCode;
use App\Models\User;
use Faker\Factory;
use Illuminate\Database\Seeder;

class TestDataSet extends Seeder
{
    /** @var $faker Faker Factory */
    private $faker;

    public function __construct()
    {
        $this->faker = Factory::create(config('app.faker_locale'));
    }

    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        for ($i = 1; $i < 22; $i++) {
            $owner = new User();

            $owner->name         = sprintf('TestGebr%d', $i);
            $owner->email        = sprintf('testgebruiker%d@test.com', $i);
            $owner->password     = bcrypt('test');
            $owner->zipcode      = '1234AB';
            $owner->street       = $this->faker->streetName;
            $owner->house_number = rand(10, 50);
            $owner->city         = $this->faker->city;

            $owner->save();

            // Create patient
            $patient = new Patient();

            $patient->name          = $this->faker->firstName;
            $patient->breed         = 'Duitse herder';
            $patient->owner_id      = $owner->id;
            $patient->date_of_birth = $this->faker->dateTimeThisDecade;

            $patient->save();

            // Create appointment
            $appointment = new Appointment();

            $appointment->patient_id        = $patient->id;
            $appointment->owner_id          = $owner->id;
            $appointment->expected_statuses = 3;
            $appointment->appointment_at    = $this->faker->dateTimeThisMonth;

            $appointment->save();

            // Create medicine
            $medicine = new Medicine();

            $medicine->name         = $this->faker->bloodType;
            $medicine->description  = $this->faker->bloodType;
            $medicine->usage         = $this->faker->bloodType;

            $medicine->save();

            // Create status record
            $status = new AppointmentStatus();

            $status->description = 'Voorbereidingen';
            $status->appointment_id = $appointment->id;

            $status->save();

            // Create tracking code
            $tracking_code = new TrackingCode();

            $tracking_code->code           = sprintf('%s00-0000-0000-0000', $i < 10 ? '0' . $i : $i);
            $tracking_code->appointment_id = $appointment->id;

            $tracking_code->save();

            // Create aftercare record
            $aftercare_record = new AftercareRecord();

            $aftercare_record->content        = 'Hier zou medisch advies komen te staan.';
            $aftercare_record->appointment_id = $appointment->id;
            $aftercare_record->medicine_id    = $medicine->id;
            $aftercare_record->patient_id    = $patient->id;
            $aftercare_record->owner_id    = $owner->id;

            $aftercare_record->save();
        }
    }
}
