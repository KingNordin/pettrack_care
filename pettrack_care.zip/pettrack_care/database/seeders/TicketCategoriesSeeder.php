<?php

namespace Database\Seeders;

use App\Models\TicketCategory;
use Illuminate\Database\Seeder;

class TicketCategoriesSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $categories = [
            ['name' => 'Medicatie'],
            ['name' => 'Algemeen'],
            ['name' => 'Financieel'],
            ['name' => 'Informatie over de praktijk'],
        ];

        foreach ($categories as $category) {
            TicketCategory::create($category);
        }
    }
}
