<?php

namespace Database\Factories;

use App\Models\Setting;
use Illuminate\Database\Eloquent\Factories\Factory;

class SettingFactory extends Factory
{
    /**
     * The name of the factory's corresponding model.
     *
     * @var string
     */
    protected $model = Setting::class;

    /**
     * Define the model's default state.
     *
     * @return array
     */
    public function definition()
    {
        $samples = [
            'theme_dark',
            'notifications_marketing',
            'notifications_appointments',
            'notifications_changelog'
        ];

        return [
            'user_id' => User::factory()->create()->id,
            'key' => $samples[array_rand($samples, 1)],
            'value' => 1,
        ];
    }
}
