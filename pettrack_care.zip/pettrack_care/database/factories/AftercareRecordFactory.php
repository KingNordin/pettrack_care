<?php

namespace Database\Factories;

use App\Models\AftercareRecord;
use App\Models\Appointment;
use Illuminate\Database\Eloquent\Factories\Factory;

class AftercareRecordFactory extends Factory
{
    /**
     * The name of the factory's corresponding model.
     *
     * @var string
     */
    protected $model = AftercareRecord::class;

    /**
     * Define the model's default state.
     *
     * @return array
     */
    public function definition()
    {
        return [
            'content' => $this->faker->text,
            'appointment_id' => Appointment::factory()->create()->id,
        ];
    }
}
