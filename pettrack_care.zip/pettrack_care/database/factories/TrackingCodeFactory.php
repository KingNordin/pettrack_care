<?php

namespace Database\Factories;

use App\Models\Appointment;
use App\Models\TrackingCode;
use Illuminate\Database\Eloquent\Factories\Factory;

class TrackingCodeFactory extends Factory
{
    /**
     * The name of the factory's corresponding model.
     *
     * @var string
     */
    protected $model = TrackingCode::class;

    /**
     * Define the model's default state.
     *
     * @return array
     */
    public function definition()
    {
        return [
            'code' => $this->faker->numerify('####-####-####-####'),
            'appointment_id' => Appointment::factory()->create()->id
        ];
    }
}
