<?php

namespace Database\Factories;

use App\Models\Patient;
use App\Models\User;
use Illuminate\Database\Eloquent\Factories\Factory;

class PatientFactory extends Factory
{
    /**
     * The name of the factory's corresponding model.
     *
     * @var string
     */
    protected $model = Patient::class;

    /**
     * Define the model's default state.
     *
     * @return array
     */
    public function definition()
    {
        return [
            'name' => $this->faker->firstName,
            'breed' => 'Shiba Inu',
            'owner_id' => User::factory()->create()->id,
            'date_of_birth' => now(),
        ];
    }

    /**
     * @param string $breed
     * @return PatientFactory
     */
    public function breed($breed = 'Shiba Inu')
    {
        return $this->state(function (array $attributes) use ($breed) {
            return [
                'breed' => $breed
            ];
        });
    }
}
